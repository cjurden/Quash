var searchData=
[
  ['set_5fenv_5fvariable',['set_env_variable',['../quash_8c.html#a6be7f36287a34e05eb22cacbe9d35113',1,'set_env_variable(const char *var, const char *val):&#160;quash.c'],['../quash_8h.html#a6be7f36287a34e05eb22cacbe9d35113',1,'set_env_variable(const char *var, const char *val):&#160;quash.c']]]
];
