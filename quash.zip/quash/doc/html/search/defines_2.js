var searchData=
[
  ['pdebug',['PDEBUG',['../debug_8h.html#a9077500d1488a75e4eec5eeb1131655e',1,'debug.h']]]
];
