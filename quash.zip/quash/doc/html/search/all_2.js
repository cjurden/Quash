var searchData=
[
  ['execute_5fecho',['execute_echo',['../quash_8c.html#a0aafd5008af86357550c2367cb0947e7',1,'execute_echo(const char *path_to_echo):&#160;quash.c'],['../quash_8h.html#a0aafd5008af86357550c2367cb0947e7',1,'execute_echo(const char *path_to_echo):&#160;quash.c']]],
  ['execvp_5fcommands',['execvp_commands',['../quash_8c.html#a8bf241f45083b492bb02d362e6986061',1,'execvp_commands(char **cmds):&#160;quash.c'],['../quash_8h.html#a8bf241f45083b492bb02d362e6986061',1,'execvp_commands(char **cmds):&#160;quash.c']]]
];
